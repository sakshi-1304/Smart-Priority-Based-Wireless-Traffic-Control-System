// Transmitter - Corrected Mapping
const int buttons[] = {2, 3, 4, 5}; 
char signals[] = {'N', 'E', 'S', 'W'}; // N=North, E=East, S=South, W=West
const int txLed = 6;

void setup() {
  Serial.begin(9600);
  pinMode(txLed, OUTPUT);
  for(int i=0; i<4; i++) {
    pinMode(buttons[i], INPUT_PULLUP);
  }
}

void loop() {
  for(int i=0; i<4; i++) {
    if(digitalRead(buttons[i]) == LOW) { // Button Pressed
      digitalWrite(txLed, HIGH);
      Serial.print(signals[i]); // Sahi letter bhejega
      delay(500); 
      digitalWrite(txLed, LOW);
      
      // Jab tak button daba hai, ruko taaki baar-baar signal na jaye
      while(digitalRead(buttons[i]) == LOW); 
    }
  }
}
// Receiver
int lights[4][3] = {
  {13, 12, 11}, // 0: North
  {10, 9, 8},   // 1: East
  {7, 6, 5},    // 2: South
  {4, 3, 2}     // 3: West
};

const int rxLed = A0; 
int currentGreen = 0; 
int state = 0; // 0: Green, 1: Yellow
unsigned long lastChange = 0;

int pendingPriority = -1; 
bool isPriorityActive = false; 
int lastNormalGreen = 0; 

// TIMINGS
unsigned long greenTime = 30000; 
unsigned long yellowTime = 5000;

void setup() {
  Serial.begin(9600);
  pinMode(rxLed, OUTPUT);
  for(int i=0; i<4; i++) {
    for(int j=0; j<3; j++) pinMode(lights[i][j], OUTPUT);
  }
  allRed();
  digitalWrite(lights[0][0], LOW); 
  digitalWrite(lights[0][2], HIGH); 
  lastChange = millis();
}

void loop() {
  // 1. Priority Signal Check
  if (Serial.available() > 0) {
    char signal = Serial.read();
    int requested = -1;
    if(signal == 'N') requested = 0;
    else if(signal == 'E') requested = 1;
    else if(signal == 'S') requested = 2;
    else if(signal == 'W') requested = 3;

    if (requested != -1 && requested != currentGreen) {
      digitalWrite(rxLed, HIGH);
      
      if (isPriorityActive) {
        // AGAR PRIORITY PEHLE SE HAI: To sirf line (queue) mein lagao
        pendingPriority = requested; 
      } 
      else {
        // AGAR NORMAL CYCLE HAI: To spot save karo aur turant switch karo
        lastNormalGreen = currentGreen;
        isPriorityActive = true; 
        pendingPriority = requested;
        if(state == 0) switchToYellow(); 
      }
      
      delay(200);
      digitalWrite(rxLed, LOW);
    }
    while(Serial.available() > 0) Serial.read(); 
  }

  // 2. Normal Timing Logic
  unsigned long now = millis();

  if (state == 0) { // GREEN PHASE
    if (now - lastChange >= greenTime) {
      switchToYellow();
    }
  } 
  else if (state == 1) { // YELLOW PHASE
    if (now - lastChange >= yellowTime) {
      switchToNextGreen();
    }
  }
}

void switchToYellow() {
  digitalWrite(lights[currentGreen][2], LOW);
  digitalWrite(lights[currentGreen][1], HIGH);
  state = 1;
  lastChange = millis();
}

void switchToNextGreen() {
  digitalWrite(lights[currentGreen][1], LOW);
  digitalWrite(lights[currentGreen][0], HIGH);
  
  if (pendingPriority != -1) {
    // Dusri priority ki bari (Pehli khatam hone ke baad)
    currentGreen = pendingPriority;
    pendingPriority = -1;
    // isPriorityActive true hi rahega
  } 
  else if (isPriorityActive) {
    // Sab priority khatam, ab normal cycle wahi se jahan ruki thi
    currentGreen = (lastNormalGreen + 1) % 4;
    isPriorityActive = false; 
  } 
  else {
    // Regular Cycle flow
    currentGreen = (currentGreen + 1) % 4;
  }

  digitalWrite(lights[currentGreen][0], LOW);
  digitalWrite(lights[currentGreen][2], HIGH);
  state = 0;
  lastChange = millis();
}

void allRed() {
  for(int i=0; i<4; i++) {
    digitalWrite(lights[i][0], HIGH); 
    digitalWrite(lights[i][1], LOW);
    digitalWrite(lights[i][2], LOW);
  }
}